package student;


import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;

public class StudentOperations implements StudentServices,Comparator<Student> {
	LinkedList<Student> slist=new LinkedList<Student>();
	int count=0;
	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		slist.add(student);
		count++;
	}

	@Override
	public void removeStudent(int sId) {
		// TODO Auto-generated method stub
		Iterator<Student> it=slist.iterator();
		while(it.hasNext()) {
			Student student=it.next();
			if(student.getsId()==sId) {
				slist.remove(student);
				count--;
				break;
			}
			}
		
	}

	@Override
	public void displayAllStudents() {
		// TODO Auto-generated method stub
		Iterator<Student> it=slist.iterator();
		while(it.hasNext()) {
			Student student=it.next();
			System.out.println(student);
			}
		
	}

	@Override
	public Student getStudentbyid(int sId) {
		// TODO Auto-generated method stub
		Iterator<Student> it=slist.iterator();
		while(it.hasNext()) {
			Student student=it.next();
			if(student.getsId()==sId) {
				return student;
			}
			}
		return null;
	}

	@Override
		public int compare(Student s1, Student s2) {
			// TODO Auto-generated method stub
			if(s1.getsMark()>s2.getsMark()) {
				return 1;
			}
			else if(s1.getsMark()<s2.getsMark()) {
				return -1;
			}
			else {
				return 0;
			}
	}
	

	
	
	

}
