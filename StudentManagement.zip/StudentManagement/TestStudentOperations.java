package student;

import java.util.Collections;
import java.util.Scanner;

public class TestStudentOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentOperations soper=new StudentOperations();
		int option=0,choice;
		do {
		Scanner sc=new Scanner(System.in);
		System.out.println("\n 1.add Student \n 2.Remove the Student \n 3.Display all students \n 4.getstudent by id \n 5.Sorting by id \n 6.Sorting by name \n 7.Sorting byId \n 8.exit");
		System.out.println("enter the option");
		option=sc.nextInt();
		switch(option) {
		case 1: System.out.println("enter the student details like student id,name,marks,grade");
		Student student=new Student(sc.nextInt(),sc.next(),sc.nextFloat(),sc.next().charAt(0));
		soper.addStudent(student);
		break;
		case 2 :System.out.println("enter the student id");
		soper.removeStudent(sc.nextInt());
		break;
		case 3: soper.displayAllStudents();
		break;
		case 4: System.out.println("enter the student id");
			Student s=soper.getStudentbyid(sc.nextInt());
			System.out.println(s);
		break;
		case 5: System.out.println("The sorting of student list by marks");
		Collections.sort(soper.slist,new StudentOperations());
		System.out.println(soper.slist);
		break;
		case 6:System.out.println("Sorting by name");
		Collections.sort(soper.slist,new NameComparator());
		System.out.println(soper.slist);
		break;
		case 7:System.out.println("Sorting by Id");
		Collections.sort(soper.slist,new IdComparator());
		System.out.println(soper.slist);
		break;
		case 8:System.exit(0);

	}System.out.println("Do You want to continue Press \n 1.yes \n 2.No");
	choice=sc.nextInt();
		}while(choice==1);
	}

}
