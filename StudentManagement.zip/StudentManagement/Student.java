package student;

public class Student {
public int getsId() {
		return sId;
	}
	public String getsName() {
		return sName;
	}
	public float getsMark() {
		return sMark;
	}
	public char getsGrade() {
		return sGrade;
	}
public Student(int sId, String sName, float sMark, char sGrade) {
		super();
		this.sId = sId;
		this.sName = sName;
		this.sMark = sMark;
		this.sGrade = sGrade;
	}
private int sId;
private String sName;
private float sMark;
private char sGrade;
@Override
public String toString() {
	return "Student [sId=" + sId + ", sName=" + sName + ", sMark=" + sMark + ", sGrade=" + sGrade + "]";
}


}
