package student;

public interface StudentServices {
	void addStudent(Student student);
	void removeStudent(int sId);
	void displayAllStudents();
	Student getStudentbyid(int sId);
	
}
